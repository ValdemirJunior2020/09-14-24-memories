export const CREATE = 'CREATE';
export const DELETE = 'DELETE';
export const FETCH_ALL = 'FETCH_ALL';
export const LIKE = 'LIKE';
export const UPDATE = 'UPDATE';
export const AUTH = 'AUTH'; // Add this line
